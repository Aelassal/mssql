/** @odoo-module **/

import { registry } from '@web/core/registry';
import { loadJS } from "@web/core/assets"
const { Component, useState, useRef, onMounted, onWillStart, useChildSubEnv} = owl
import { Dropdown } from "@web/core/dropdown/dropdown";
import { DropdownItem } from "@web/core/dropdown/dropdown_item";
import { DateTimePicker } from "@web/core/datetime/datetime_picker";
import { DateTimeInput } from "@web/core/datetime/datetime_input";
import { serializeDate, deserializeDate } from "@web/core/l10n/dates";
const { DateTime } = luxon;
import { useBus, useService,  } from "@web/core/utils/hooks";
import { PycusPartnerLedgerLine } from "../pycus_partner_ledger/pycus_partner_ledger_line";
import { PycusPartnerLedgerFilters } from "../pycus_partner_ledger/pycus_partner_ledger_filters";

export class PycusPartnerLedger extends Component {
    setup(){
        this.ormService = useService("orm");
        this.action = useService("action");
        this.state = useState({
            activeId: 0,
            filterValues: {},
            gl_lines: [],
            showLoader: true,
            searchQuery: '',
            unfoldAll: false,
            sortField: '',
            sortDirection: 'asc',
        });

        onWillStart(async ()=> {
            await this.createGlWizard();
        })

        onMounted(() => {
            this.apply_filters();
            this.state.isFilterVisible = false;
        })

        this.createGlWizard = async () => {
            try {
                let glWizardId = 0
                if (this.props.action.context.active_id){
                    glWizardId = this.props.action.context.active_id
                }else{
                    glWizardId = await this.ormService.call('ins.partner.ledger', 'create', [{}]);
                }
                this.state.activeId = glWizardId
                this.readGlWizard(glWizardId);
            } catch (error) {
                console.log("Error on GL Creation", error)
            }
        };

        this.readGlWizard = async () => {
              try {
                const record = await this.ormService.call('ins.partner.ledger', 'prepare_values_for_component', [this.state.activeId]); // Choose relevant fields
                this.state.filterValues = record
              } catch (error) {
                console.error("Error reading record:", error);
              }
        };

        this.apply_filters = async () => {
            this.showSpinner()
            //update_values_from_component
            this.state.isFilterVisible = false;
            const filter_values = this.state.filterValues
            try {
                const gl_lines = await this.ormService.call('ins.partner.ledger', 'update_values_from_component', [this.state.activeId, filter_values]); // Choose relevant fields
                this.state.gl_lines = gl_lines
                this.readGlWizard()
              } catch (error) {
                console.error("Error reading record:", error);
              }
            this.hideSpinner()
        }

    }

    toggleVisibility() {
        this.state.isFilterVisible = !this.state.isFilterVisible;
    }

    onSearchInput(ev) {
        this.state.searchQuery = ev.target.value;
    }

    toggleUnfoldAll() {
        this.state.unfoldAll = !this.state.unfoldAll;
    }

    get filteredLines() {
        const query = (this.state.searchQuery || '').trim().toLowerCase();
        if (!query) return this.state.gl_lines;
        return this.state.gl_lines.filter(
            line => (line.partner_name || '').toLowerCase().includes(query)
        );
    }

    onSortColumn(field) {
        if (this.state.sortField === field) {
            this.state.sortDirection = this.state.sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            this.state.sortField = field;
            this.state.sortDirection = 'asc';
        }
    }

    get sortedLines() {
        const lines = this.filteredLines;
        if (!this.state.sortField) return lines;
        const field = this.state.sortField;
        const dir = this.state.sortDirection === 'asc' ? 1 : -1;
        return [...lines].sort((a, b) => {
            const va = a[field] ?? '';
            const vb = b[field] ?? '';
            if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * dir;
            return String(va).localeCompare(String(vb)) * dir;
        });
    }

    getFilterValues(val){
        this.state.filterValues = val.state
    }

    async downloadXlsx($this) {
        const action = await this.ormService.call('ins.partner.ledger', 'action_xlsx', [this.state.activeId]);
        this.action.doAction(action);
    }

    async downloadPdf($this) {
        const action = await this.ormService.call('ins.partner.ledger', 'action_pdf', [this.state.activeId]);
        this.action.doAction(action);
    }

    showSpinner() {
        this.state.showLoader = true;
    }

    hideSpinner() {
       this.state.showLoader = false;
    }


}
PycusPartnerLedger.template = 'account_dynamic_reports.partnerLedger';
PycusPartnerLedger.components = {
    Dropdown, DropdownItem, DatePicker: DateTimePicker, DateTimeInput,
    PycusPartnerLedgerLine, PycusPartnerLedgerFilters};
registry.category('actions').add('account_dynamic_reports.action_partner_ledger', PycusPartnerLedger)